import re

fichier = open("domains.xml", "r")

searching = re.search(".com", fichier)

print(searching)