text = input("Entrez une phrase")

fichier = open("test.txt", "w")
fichier.write(text)
fichier.close()
