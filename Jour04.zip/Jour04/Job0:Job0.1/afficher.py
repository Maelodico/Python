
fichier = open("test.txt", "r")
print(fichier.read())

fichier.close()