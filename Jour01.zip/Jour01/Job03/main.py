print(3+2)
