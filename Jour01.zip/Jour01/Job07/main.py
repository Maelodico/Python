def Add(a, b):
    return a + b

print(Add(5, 5))
print(Add(19, 2))
print(Add(2, 3))